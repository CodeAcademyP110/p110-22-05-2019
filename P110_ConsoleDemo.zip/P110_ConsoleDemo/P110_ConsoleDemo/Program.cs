﻿using System;
using System.Net.Mail;
using System.Text;
using PrimaryClasses;

namespace P110_ConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Upcasting and downcasting
            //int n = 15;
            //string word = "Samir";

            ////upcasting
            //object o1 = n;
            //object o2 = word;

            //downcasting insecure way
            //try
            //{
            //    int m = (int)o2;
            //}
            //catch
            //{
            //    Console.WriteLine("o2 is not an integer");
            //}

            //downcastin secure way 1.
            //string s = o2 as string;

            //if(s == null)
            //{
            //    Console.WriteLine("o1 string doyul");
            //}
            //else
            //{
            //    Console.WriteLine(s);
            //}

            //downcastin secure way 2.
            //if(o2 is int)
            //{
            //    Console.WriteLine("Integer: {0}", (int)o2);
            //}
            //else if(o2 is string)
            //{
            //    Console.WriteLine("String: {0}", (string)o2);
            //}

            //Console.WriteLine(Demo(15, "samir", true, 20, 30));
            #endregion

            #region Implicit & explicit conversion
            //Fahrenheit fahrenheit = new Fahrenheit
            //{
            //    Temp = 150F
            //};

            //Celcius d2 = (Celcius)fahrenheit;

            //implicit case:
            //1. No data loss should happen
            //2. No exception should be thrown inside conversion

            //explicit case:
            //1. Data loss is possible
            //2. Exception can be thrown

            //Rectangle rectangle = new Rectangle
            //{
            //    LeftS = 10F,
            //    RightS = 15F,
            //    BottomS = 20F,
            //    TopS = 30F
            //};

            //Triangle triangle = (Triangle)rectangle;

            //Console.WriteLine(rectangle);
            //Console.WriteLine(triangle);
            #endregion

            //Triangle triangle = new Triangle { LeftS = 10F, RightS = 20F, BottomS = 15F };
            //Triangle triangle2 = new Triangle { LeftS = 15F, RightS = 12F, BottomS = 10F };
            //Console.WriteLine(triangle + triangle2);

            Dimension dimension1 = new Dimension(25F, 100F, 50F);
            Dimension dimension2 = new Dimension(15F, 100F, 20F);

            Console.WriteLine(dimension1 < dimension2);
        }

        #region Upcasting and downcasting Outer part
        //static int Demo(params object[] objects)
        //{
        //    int sum = 0;
        //    foreach (object item in objects)
        //    {
        //        if (item is int)
        //        {
        //            sum += (int)item;
        //        }
        //    }
        //    return sum;
        //}
        #endregion

    }

    public class Dimension
    {
        public float Width { get; set; }
        public float Length { get; set; }
        public float Height { get; set; }

        public Dimension(float width, float length)
        {
            Width = width;
            Length = length;
            Height = 1;
        }

        public Dimension(float width, float length, float height) : this(width, length)
        {
            Height = height;
        }

        public float Area
        {
            get
            {
                return Width * Length * Height;
            }
        }

        public static bool operator >(Dimension d1, Dimension d2)
        {
            return d1.Area > d2.Area;
        }

        public static bool operator <(Dimension d1, Dimension d2)
        {
            return !(d1 > d2);
        }

        public override string ToString()
        {
            return $"Width: {Width} cm; Length: {Length} cm; Height: {Height} cm";
        }
    }

    public class Triangle
    {
        public float LeftS { get; set; }
        public float RightS { get; set; }
        public float BottomS { get; set; }

        public float Perimeter {
            get
            {
                return LeftS + RightS + BottomS;
            }
        }

        public static bool operator >(Triangle t1, Triangle t2)
        {
            return t1.Perimeter > t2.Perimeter;
        }

        public static bool operator <(Triangle t1, Triangle t2)
        {
            return t1.Perimeter < t2.Perimeter;
        }

        public static Triangle operator +(Triangle t1, Triangle t2)
        {
            return new Triangle
            {
                LeftS = t1.LeftS + t2.LeftS,
                RightS = t1.RightS + t2.RightS,
                BottomS = t1.BottomS + t2.BottomS
            };
        }


        public override string ToString()
        {
            return $"Left: {LeftS} cm; Right: {RightS} cm; Bottom: {BottomS} cm";
        }
    }

    public class Rectangle
    {
        public float LeftS { get; set; }
        public float RightS { get; set; }
        public float TopS { get; set; }
        public float BottomS { get; set; }

        public static explicit operator Triangle(Rectangle r)
        {
            return new Triangle
            {
                LeftS = r.LeftS,
                RightS = r.RightS,
                BottomS = r.BottomS
            };
        }

        public override string ToString()
        {
            return $"Left: {LeftS} cm; Right: {RightS} cm; Bottom: {BottomS} cm; Top: {TopS} cm";
        }
    }

    public class Celcius
    {
        public float Degree { get; set; }

        public static bool operator >(Celcius c1, Celcius c2)
        {
            return c1.Degree > c2.Degree;
        }

        public static bool operator <(Celcius c1, Celcius c2)
        {
            return c1.Degree < c2.Degree;
        }

        public static implicit operator Celcius(float f)
        {
            //Celcius c = new Celcius();
            //c.Degree = f;
            //return c;
            return new Celcius { Degree = f };
        }

        public static implicit operator Fahrenheit(Celcius c)
        {
            return new Fahrenheit { Temp = c.Degree * 9 / 5 + 32 };
        }

        public override string ToString()
        {
            return $"{Degree} C";
        }
    }

    public class Fahrenheit
    {
        public float Temp { get; set; }

        public static explicit operator Celcius(Fahrenheit f)
        {
            //Celcius c = new Celcius();
            //c.Degree = (f.Temp - 32) * 5 / 9;
            //return c;

            return new Celcius { Degree = (f.Temp - 32) * 5 / 9 };
        }

        public override string ToString()
        {
            return $"{Temp} F";
        }
    }

    //polymorphism
    public abstract class Animal
    {
        public abstract void Eat();
    }

    public abstract class FourLegs : Animal
    {
        public abstract void Run();
    }

    public abstract class Reptiles : Animal
    {
        public abstract void Rept();
    }

    public class Snake : Reptiles
    {
        public override void Rept()
        {
            Console.WriteLine("I am repting");
        }

        public override void Eat()
        {
            Console.WriteLine("I am eating as Snake");
        }
    }

    public class Rabbit : FourLegs
    {
        public string Sort { get; set; }

        public Rabbit(string sort)
        {
            Sort = sort;
        }

        public override void Eat()
        {
            Console.WriteLine("I am eating");
        }

        public override void Run()
        {
            Console.WriteLine("I am running");
        }

        public void Demo(Animal a) {
            Reptiles r = (Reptiles)a;
        }
    }
}

